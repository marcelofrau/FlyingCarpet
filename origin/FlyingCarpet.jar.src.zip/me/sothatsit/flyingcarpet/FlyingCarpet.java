/*     */ package me.sothatsit.flyingcarpet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Logger;
/*     */ import me.sothatsit.flyingcarpet.message.ConfigWrapper;
/*     */ import me.sothatsit.flyingcarpet.message.Messages;
/*     */ import me.sothatsit.flyingcarpet.model.Model;
/*     */ import me.sothatsit.flyingcarpet.util.BlockData;
/*     */ import me.sothatsit.flyingcarpet.util.LocationUtils;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.command.PluginCommand;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPistonExtendEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.hanging.HangingBreakEvent;
/*     */ import org.bukkit.event.player.PlayerKickEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.event.player.PlayerToggleSneakEvent;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class FlyingCarpet extends org.bukkit.plugin.java.JavaPlugin implements Listener
/*     */ {
/*     */   private static FlyingCarpet instance;
/*     */   private Model base;
/*     */   private Model tools;
/*     */   private Model light;
/*     */   private List<BlockData> passThrough;
/*     */   private int descendSpeed;
/*  48 */   private List<UPlayer> players = new ArrayList();
/*     */   
/*  50 */   private boolean worldguardHooked = false;
/*     */   private Set<RegionHook> regionHooks;
/*     */   
/*     */   public void onEnable()
/*     */   {
/*  55 */     instance = this;
/*     */     
/*  57 */     this.regionHooks = new java.util.HashSet();
/*     */     
/*  59 */     getCommand("flyingcarpet").setExecutor(new FlyingCarpetCommand());
/*  60 */     Bukkit.getPluginManager().registerEvents(this, this);
/*     */     
/*  62 */     Messages.setConfig(new ConfigWrapper(this, "lang.yml"));
/*     */     
/*  64 */     if (Bukkit.getPluginManager().getPlugin("WorldGuard") != null) {
/*     */       try {
/*  66 */         this.regionHooks.add(new WorldGuardHook());
/*  67 */         this.worldguardHooked = true;
/*     */       } catch (Exception e) {
/*  69 */         getLogger().severe("Exception hooking WorldGuard");
/*  70 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*  74 */     reloadConfiguration();
/*     */   }
/*     */   
/*     */   public void onDisable()
/*     */   {
/*  79 */     instance = null;
/*     */     
/*  81 */     for (UPlayer up : this.players) {
/*  82 */       up.setEnabled(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCarpetAllowed(Location loc) {
/*  87 */     for (RegionHook hook : this.regionHooks) {
/*  88 */       if (!hook.isCarpetAllowed(loc)) {
/*  89 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isWorldGuardHooked() {
/*  97 */     return getWorldGuardHook() != null;
/*     */   }
/*     */   
/*     */   public RegionHook getWorldGuardHook() {
/* 101 */     for (RegionHook hook : this.regionHooks) {
/* 102 */       if (hook.getClass().equals(WorldGuardHook.class)) {
/* 103 */         return hook;
/*     */       }
/*     */     }
/*     */     
/* 107 */     return null;
/*     */   }
/*     */   
/*     */   public ConfigWrapper loadConfig() {
/* 111 */     ConfigWrapper configWrapper = new ConfigWrapper(this, "config.yml");
/*     */     
/* 113 */     configWrapper.saveDefaults();
/* 114 */     configWrapper.reload();
/*     */     
/* 116 */     return configWrapper;
/*     */   }
/*     */   
/*     */   public void reloadConfiguration() {
/* 120 */     ConfigWrapper configWrapper = loadConfig();
/*     */     
/* 122 */     FileConfiguration config = configWrapper.getConfig();
/*     */     
/* 124 */     if ((!config.isSet("pass-through")) || (!config.isList("pass-through"))) {
/* 125 */       getLogger().warning("\"pass-through\" not set or invalid in config, resetting to default");
/* 126 */       config.set("pass-through", configWrapper.getDefaultConfig().get("pass-through"));
/* 127 */       configWrapper.save();
/*     */     }
/*     */     
/* 130 */     if ((!config.isSet("descend-speed")) || (!config.isInt("descend-speed"))) {
/* 131 */       getLogger().warning("\"descend-speed\" not set or invalid in config, resetting to default");
/* 132 */       config.set("descend-speed", configWrapper.getDefaultConfig().get("descend-speed"));
/* 133 */       configWrapper.save();
/*     */     }
/*     */     
/* 136 */     this.descendSpeed = config.getInt("descend-speed");
/*     */     
/* 138 */     List<String> passThrough = config.getStringList("pass-through");
/* 139 */     this.passThrough = new ArrayList();
/*     */     
/* 141 */     this.passThrough.add(BlockData.AIR);
/*     */     
/* 143 */     for (String str : passThrough) {
/* 144 */       if (str.equalsIgnoreCase("water")) {
/* 145 */         BlockData stillWater = new BlockData(Material.STATIONARY_WATER);
/* 146 */         BlockData runningWater = new BlockData(Material.WATER);
/*     */         
/* 148 */         this.passThrough.add(stillWater);
/* 149 */         this.passThrough.add(runningWater);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 154 */       else if (str.equalsIgnoreCase("lava")) {
/* 155 */         BlockData stillLava = new BlockData(Material.STATIONARY_LAVA);
/* 156 */         BlockData runningLava = new BlockData(Material.LAVA);
/*     */         
/* 158 */         this.passThrough.add(stillLava);
/* 159 */         this.passThrough.add(runningLava);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 164 */         String[] split = str.split(":");
/*     */         
/* 166 */         if (split.length == 0) {
/* 167 */           getLogger().warning("Invalid pass through block \"" + str + "\"");
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/* 174 */             int id = Integer.valueOf(split[0]).intValue();
/* 175 */             type = Material.getMaterial(id);
/*     */           } catch (NumberFormatException e) { Material type;
/* 177 */             getLogger().warning("Invalid pass through block \"" + str + "\", type must be an integer"); }
/* 178 */           continue;
/*     */           
/*     */           int id;
/* 181 */           if (type == null) {
/* 182 */             getLogger().warning("Invalid pass through block \"" + str + "\", invalid material \"" + id + "\"");
/*     */ 
/*     */ 
/*     */           }
/* 186 */           else if (split.length == 1)
/* 187 */             this.passThrough.add(new BlockData(type));
/*     */         }
/*     */       }
/*     */     }
/*     */     Material type;
/* 192 */     if (!config.isConfigurationSection("model")) {
/* 193 */       getLogger().warning("\"model\" not set or invalid in config, resetting to default");
/* 194 */       config.set("model", null);
/*     */       
/* 196 */       ConfigurationSection sec = config.createSection("model");
/* 197 */       copySection(configWrapper, config, sec);
/*     */     }
/*     */     
/* 200 */     ConfigurationSection model = config.getConfigurationSection("model");
/*     */     
/* 202 */     if (!model.isSet("base")) {
/* 203 */       getLogger().warning("\"model.base\" not set or invalid in config, resetting to default");
/* 204 */       model.set("base", null);
/*     */       
/* 206 */       ConfigurationSection sec = model.createSection("base");
/* 207 */       copySection(configWrapper, config, sec);
/*     */     }
/*     */     
/* 210 */     if (!model.isSet("tools")) {
/* 211 */       getLogger().warning("\"model.tools\" not set or invalid in config, resetting to default");
/* 212 */       model.set("tools", null);
/*     */       
/* 214 */       ConfigurationSection sec = model.createSection("tools");
/* 215 */       copySection(configWrapper, config, sec);
/*     */     }
/*     */     
/* 218 */     if (!model.isSet("light")) {
/* 219 */       getLogger().warning("\"model.light\" not set or invalid in config, resetting to default");
/* 220 */       model.set("light", null);
/*     */       
/* 222 */       ConfigurationSection sec = model.createSection("light");
/* 223 */       copySection(configWrapper, config, sec);
/*     */     }
/*     */     
/* 226 */     ConfigurationSection baseSec = model.getConfigurationSection("base");
/* 227 */     ConfigurationSection toolsSec = model.getConfigurationSection("tools");
/* 228 */     ConfigurationSection lightSec = model.getConfigurationSection("light");
/*     */     
/* 230 */     this.base = Model.fromConfig(baseSec);
/* 231 */     this.tools = Model.fromConfig(toolsSec);
/* 232 */     this.light = Model.fromConfig(lightSec);
/*     */     
/* 234 */     for (RegionHook hook : this.regionHooks) {
/* 235 */       hook.reloadConfiguration(config);
/*     */     }
/*     */     
/* 238 */     configWrapper.save();
/*     */   }
/*     */   
/*     */   private static void copySection(ConfigWrapper config, FileConfiguration conf, ConfigurationSection section) {
/* 242 */     boolean changed = false;
/* 243 */     FileConfiguration defaults = config.getDefaultConfig();
/*     */     
/* 245 */     for (String key : defaults.getKeys(true)) {
/* 246 */       if ((key.startsWith(section.getCurrentPath())) && (!conf.isSet(key))) {
/* 247 */         if (conf.isConfigurationSection(key)) {
/* 248 */           conf.createSection(key);
/* 249 */           changed = true;
/*     */         }
/*     */         else
/*     */         {
/* 253 */           conf.set(key, defaults.get(key));
/* 254 */           changed = true;
/*     */         }
/*     */       }
/*     */     }
/* 258 */     if (changed)
/* 259 */       config.save();
/*     */   }
/*     */   
/*     */   public UPlayer getUPlayer(Player p) {
/* 263 */     for (UPlayer up : this.players) {
/* 264 */       if (up.getPlayer().getUniqueId().equals(p.getUniqueId())) {
/* 265 */         return up;
/*     */       }
/*     */     }
/* 268 */     UPlayer up = new UPlayer(p);
/*     */     
/* 270 */     this.players.add(up);
/*     */     
/* 272 */     return up;
/*     */   }
/*     */   
/*     */   public UPlayer getUPlayer(UUID uuid) {
/* 276 */     for (UPlayer up : this.players) {
/* 277 */       if (up.getPlayer().getUniqueId().equals(uuid))
/* 278 */         return up;
/*     */     }
/* 280 */     return null;
/*     */   }
/*     */   
/*     */   public void removeUPlayer(Player p) {
/* 284 */     UPlayer up = getUPlayer(p);
/*     */     
/* 286 */     if (up == null) {
/* 287 */       return;
/*     */     }
/* 289 */     this.players.remove(up);
/*     */     
/* 291 */     up.setEnabled(false);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerQuit(PlayerQuitEvent e) {
/* 296 */     removeUPlayer(e.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerKick(PlayerKickEvent e) {
/* 301 */     removeUPlayer(e.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onBlockBreak(BlockBreakEvent e) {
/* 306 */     for (UPlayer up : this.players) {
/* 307 */       Player p = up.getPlayer();
/*     */       
/* 309 */       if (!up.isCarpetBlock(e.getBlock())) {
/* 310 */         if (up.isEnabled()) {
/* 311 */           final UUID uuid = p.getUniqueId();
/* 312 */           new BukkitRunnable()
/*     */           {
/*     */             public void run() {
/* 315 */               UPlayer up = FlyingCarpet.this.getUPlayer(uuid);
/*     */               
/* 317 */               if (up == null) {
/* 318 */                 return;
/*     */               }
/* 320 */               up.createCarpet(); } }
/*     */           
/* 322 */             .runTask(this);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 328 */         e.setCancelled(true);
/* 329 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/* 335 */   public void onBlockPistonExtend(BlockPistonExtendEvent e) { for (Iterator localIterator1 = e.getBlocks().iterator(); localIterator1.hasNext();) { b = (Block)localIterator1.next();
/* 336 */       for (UPlayer up : this.players)
/* 337 */         if (up.isCarpetBlock(b))
/*     */         {
/*     */ 
/* 340 */           e.setCancelled(true); return;
/*     */         }
/*     */     }
/*     */     Block b;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onHangingBreak(HangingBreakEvent e) {
/* 348 */     for (UPlayer up : this.players)
/* 349 */       if (up.isCarpetBlock(e.getEntity().getLocation()))
/*     */       {
/*     */ 
/* 352 */         e.setCancelled(true);
/* 353 */         return;
/*     */       }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityExplode(EntityExplodeEvent e) {
/* 359 */     List<Block> remove = new ArrayList();
/*     */     
/* 361 */     for (Iterator localIterator1 = e.blockList().iterator(); localIterator1.hasNext();) { b = (Block)localIterator1.next();
/* 362 */       for (UPlayer up : this.players) {
/* 363 */         Player p = up.getPlayer();
/*     */         
/* 365 */         if (!up.isCarpetBlock(b)) {
/* 366 */           if (up.isEnabled()) {
/* 367 */             final UUID uuid = p.getUniqueId();
/* 368 */             new BukkitRunnable()
/*     */             {
/*     */               public void run() {
/* 371 */                 UPlayer up = FlyingCarpet.this.getUPlayer(uuid);
/*     */                 
/* 373 */                 if (up == null) {
/* 374 */                   return;
/*     */                 }
/* 376 */                 up.createCarpet(); } }
/*     */             
/* 378 */               .runTask(this);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/* 384 */           remove.add(b);
/*     */       }
/*     */     }
/*     */     Block b;
/* 388 */     for (Block block : remove) {
/* 389 */       e.blockList().remove(block);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onEntityDamage(EntityDamageEvent e) {
/* 395 */     if (e.getCause() != EntityDamageEvent.DamageCause.SUFFOCATION) {
/*     */       return;
/*     */     }
/*     */     LivingEntity le;
/*     */     Location[] locs;
/*     */     Location[] locs;
/* 401 */     if ((e.getEntity() instanceof LivingEntity)) {
/* 402 */       le = (LivingEntity)e.getEntity();
/*     */       
/* 404 */       locs = new Location[] { le.getLocation(), le.getEyeLocation() };
/*     */     } else {
/* 406 */       locs = new Location[] { e.getEntity().getLocation() };
/*     */     }
/*     */     Location loc;
/* 409 */     for (loc : locs) {
/* 410 */       for (UPlayer up : this.players) {
/* 411 */         if (up.isCarpetBlock(loc)) {
/* 412 */           e.setCancelled(true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerDamage(EntityDamageEvent e) {
/* 420 */     if (e.getCause() != EntityDamageEvent.DamageCause.FALL) {
/* 421 */       return;
/*     */     }
/*     */     
/* 424 */     if (!(e.getEntity() instanceof Player)) {
/* 425 */       return;
/*     */     }
/*     */     
/* 428 */     Player p = (Player)e.getEntity();
/* 429 */     UPlayer up = getUPlayer(p);
/*     */     
/* 431 */     if (up.isEnabled()) {
/* 432 */       e.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void onPlayerTeleport(PlayerTeleportEvent e) {
/* 438 */     if ((e.isCancelled()) || (LocationUtils.locEqual(e.getFrom(), e.getTo()))) {
/* 439 */       return;
/*     */     }
/*     */     
/* 442 */     UPlayer up = getUPlayer(e.getPlayer());
/*     */     
/* 444 */     if ((LocationUtils.locColumnEqual(e.getFrom(), e.getTo())) && (Math.abs(e.getFrom().getY() - e.getTo().getY()) <= 2.0D)) {
/* 445 */       up.setLocation(e.getTo().clone().subtract(0.0D, 1.0D, 0.0D));
/* 446 */       return;
/*     */     }
/*     */     
/* 449 */     if ((up.isEnabled()) && (!e.getPlayer().hasPermission("flyingcarpet.teleport"))) {
/* 450 */       up.setEnabled(false);
/* 451 */       Messages.get("message.teleport-remove").send(e.getPlayer());
/*     */     } else {
/* 453 */       up.setLocation(e.getTo().clone().subtract(0.0D, 1.0D, 0.0D));
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void onPlayerMove(PlayerMoveEvent e) {
/* 459 */     if ((e.isCancelled()) || (LocationUtils.locEqual(e.getFrom(), e.getTo()))) {
/* 460 */       return;
/*     */     }
/* 462 */     UPlayer up = getUPlayer(e.getPlayer());
/*     */     
/* 464 */     if ((up.isEnabled()) && (up.getLocation().getBlockY() == e.getTo().getBlockY()) && (up.isCarpetBlock(e.getTo().getBlock()))) {
/* 465 */       Location loc = e.getPlayer().getLocation();
/*     */       
/* 467 */       loc.setY(up.getLocation().getBlockY() + 1.2D);
/*     */       
/* 469 */       e.getPlayer().teleport(loc);
/* 470 */       return;
/*     */     }
/*     */     
/* 473 */     up.setLocation(e.getTo().clone().subtract(0.0D, 1.0D, 0.0D));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerToggleSneak(PlayerToggleSneakEvent e) {
/* 478 */     if (!e.isSneaking()) {
/* 479 */       getUPlayer(e.getPlayer()).cancelDescendTimer();
/* 480 */       return;
/*     */     }
/*     */     
/* 483 */     UPlayer up = getUPlayer(e.getPlayer());
/*     */     
/* 485 */     up.setLocation(e.getPlayer().getLocation().subtract(0.0D, 2.0D, 0.0D));
/* 486 */     up.createDescendTimer();
/*     */   }
/*     */   
/*     */   public static Model getBaseModel() {
/* 490 */     return instance.base;
/*     */   }
/*     */   
/*     */   public static Model getToolsModel() {
/* 494 */     return instance.tools;
/*     */   }
/*     */   
/*     */   public static Model getLightModel() {
/* 498 */     return instance.light;
/*     */   }
/*     */   
/*     */   public static boolean canPassThrough(Material type, byte data) {
/* 502 */     for (BlockData pass : instance.passThrough) {
/* 503 */       if ((pass.getType() == type) && ((pass.getData() < 0) || (pass.getData() == data)))
/* 504 */         return true;
/*     */     }
/* 506 */     return false;
/*     */   }
/*     */   
/*     */   public static int getDescendSpeed() {
/* 510 */     return instance.descendSpeed;
/*     */   }
/*     */   
/*     */   public static FlyingCarpet getInstance() {
/* 514 */     return instance;
/*     */   }
/*     */ }


/* Location:              /home/marcelo-frau/Dropbox/mundominecraft_/sources/FlyingCarpet/FlyingCarpet.jar!/me/sothatsit/flyingcarpet/FlyingCarpet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */