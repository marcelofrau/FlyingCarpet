/*     */ package me.sothatsit.flyingcarpet.message;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class Message
/*     */ {
/*     */   private String key;
/*     */   private List<String> messages;
/*     */   private List<Argument> arguments;
/*     */   
/*     */   public Message(String key)
/*     */   {
/*  20 */     this.key = key;
/*  21 */     this.messages = new ArrayList();
/*  22 */     this.arguments = new ArrayList();
/*     */     
/*  24 */     this.messages.add("Unable to find the message \"" + key + "\"");
/*     */   }
/*     */   
/*     */   public Message(String key, List<String> messages) {
/*  28 */     this.key = key;
/*  29 */     this.messages = new ArrayList(messages);
/*  30 */     this.arguments = new ArrayList();
/*     */   }
/*     */   
/*     */   public Message(String key, String message) {
/*  34 */     this.key = key;
/*  35 */     this.messages = new ArrayList(Arrays.asList(new String[] { message }));
/*  36 */     this.arguments = new ArrayList();
/*     */   }
/*     */   
/*     */   public String getKey() {
/*  40 */     return this.key;
/*     */   }
/*     */   
/*     */   public List<String> getMessages() {
/*  44 */     List<String> coloured = new ArrayList();
/*     */     
/*  46 */     for (String message : this.messages) {
/*  47 */       for (Argument a : this.arguments) {
/*  48 */         message = a.replace(message);
/*     */       }
/*     */       
/*  51 */       coloured.add(ChatColor.translateAlternateColorCodes('&', message));
/*     */     }
/*     */     
/*  54 */     return coloured;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/*  58 */     if (this.messages.size() > 0) {
/*  59 */       String message = (String)this.messages.get(0);
/*     */       
/*  61 */       for (Argument a : this.arguments) {
/*  62 */         message = a.replace(message);
/*     */       }
/*     */       
/*  65 */       return ChatColor.translateAlternateColorCodes('&', message);
/*     */     }
/*     */     
/*  68 */     return "";
/*     */   }
/*     */   
/*     */   public List<Argument> getArguments() {
/*  72 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public Message argument(String key, String value) {
/*  76 */     this.arguments.add(new Argument(key, value));
/*     */     
/*  78 */     return this;
/*     */   }
/*     */   
/*     */   public Message arguments(Argument... arguments) {
/*  82 */     return arguments(Arrays.asList(arguments));
/*     */   }
/*     */   
/*     */   public Message arguments(List<Argument> arguments) {
/*  86 */     this.arguments.addAll(arguments);
/*     */     
/*  88 */     return this;
/*     */   }
/*     */   
/*     */   public Message message(String message) {
/*  92 */     this.messages.add(message);
/*     */     
/*  94 */     return this;
/*     */   }
/*     */   
/*     */   public void send(CommandSender sender) {
/*  98 */     for (String message : this.messages)
/*  99 */       if ((message != null) && ((this.messages.size() != 1) || (!message.isEmpty())))
/*     */       {
/*     */ 
/* 102 */         for (Argument a : this.arguments) {
/* 103 */           message = a.replace(message);
/*     */         }
/*     */         
/* 106 */         message = new Argument("%reciever%", sender.getName()).replace(message);
/*     */         
/* 108 */         message = ChatColor.translateAlternateColorCodes('&', message);
/*     */         
/* 110 */         sender.sendMessage(message);
/*     */       }
/*     */   }
/*     */   
/*     */   public void broadcast() {
/* 115 */     broadcastPlayers(Bukkit.getOnlinePlayers());
/* 116 */     send(Bukkit.getConsoleSender());
/*     */   }
/*     */   
/*     */   public void broadcastPlayers(Player... players) {
/* 120 */     broadcastPlayers(Arrays.asList(players));
/*     */   }
/*     */   
/*     */   public void broadcastPlayers(java.util.Collection<? extends Player> players) {
/* 124 */     List<CommandSender> recievers = new ArrayList();
/*     */     
/* 126 */     recievers.addAll(players);
/*     */     
/* 128 */     broadcastSenders(recievers);
/*     */   }
/*     */   
/*     */   public void broadcastSenders(List<CommandSender> recievers) {
/* 132 */     for (Iterator localIterator1 = this.messages.iterator(); localIterator1.hasNext();) { message = (String)localIterator1.next();
/* 133 */       if ((message != null) && ((this.messages.size() != 1) || (!message.isEmpty())))
/*     */       {
/*     */ 
/*     */ 
/* 137 */         for (Argument a : this.arguments) {
/* 138 */           message = a.replace(message);
/*     */         }
/*     */         
/* 141 */         message = ChatColor.translateAlternateColorCodes('&', message);
/*     */         
/* 143 */         for (CommandSender sender : recievers) {
/* 144 */           message = new Argument("%reciever%", sender.getName()).replace(message);
/*     */           
/* 146 */           sender.sendMessage(message);
/*     */         }
/*     */       }
/*     */     }
/*     */     String message; }
/*     */   
/* 152 */   public void broadcastPermission(String permission) { for (String message : this.messages) {
/* 153 */       if ((message != null) && ((this.messages.size() != 1) || (!message.isEmpty())))
/*     */       {
/*     */ 
/*     */ 
/* 157 */         for (Argument a : this.arguments) {
/* 158 */           message = a.replace(message);
/*     */         }
/*     */         
/* 161 */         message = ChatColor.translateAlternateColorCodes('&', message);
/*     */         
/* 163 */         Bukkit.broadcast(message, permission);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/marcelo-frau/Dropbox/mundominecraft_/sources/FlyingCarpet/FlyingCarpet.jar!/me/sothatsit/flyingcarpet/message/Message.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */