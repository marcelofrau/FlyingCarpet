/*     */ package me.sothatsit.flyingcarpet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.sothatsit.flyingcarpet.message.Message;
/*     */ import me.sothatsit.flyingcarpet.message.Messages;
/*     */ import me.sothatsit.flyingcarpet.model.Model;
/*     */ import me.sothatsit.flyingcarpet.util.BlockData;
/*     */ import me.sothatsit.flyingcarpet.util.LocationUtils;
/*     */ import me.sothatsit.flyingcarpet.util.Region;
/*     */ import me.sothatsit.flyingcarpet.util.Vector3I;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPlayer
/*     */ {
/*     */   private Player player;
/*     */   private Location loc;
/*     */   private boolean enabled;
/*     */   private boolean tools;
/*     */   private boolean light;
/*     */   private List<BlockState> blocks;
/*     */   private BukkitRunnable descendTimer;
/*     */   
/*     */   public UPlayer(Player player)
/*     */   {
/*  34 */     this.player = player;
/*  35 */     this.loc = player.getLocation().subtract(0.0D, 1.0D, 0.0D);
/*  36 */     this.enabled = false;
/*  37 */     this.tools = false;
/*  38 */     this.light = false;
/*  39 */     this.blocks = new ArrayList();
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/*  43 */     return this.player;
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/*  47 */     return this.loc;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  51 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public boolean isTools() {
/*  55 */     return this.tools;
/*     */   }
/*     */   
/*     */   public boolean isLight() {
/*  59 */     return this.light;
/*     */   }
/*     */   
/*     */   public BukkitRunnable getDescendTimer() {
/*  63 */     return this.descendTimer;
/*     */   }
/*     */   
/*     */   public void cancelDescendTimer() {
/*  67 */     if (this.descendTimer != null) {
/*  68 */       this.descendTimer.cancel();
/*  69 */       this.descendTimer = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void createDescendTimer() {
/*  74 */     cancelDescendTimer();
/*     */     
/*  76 */     this.descendTimer = new BukkitRunnable()
/*     */     {
/*     */       public void run() {
/*  79 */         if ((UPlayer.this.player == null) || (!UPlayer.this.player.isOnline())) {
/*  80 */           cancel();
/*  81 */           return;
/*     */         }
/*     */         
/*  84 */         UPlayer.this.setLocation(UPlayer.this.player.getLocation().subtract(0.0D, 2.0D, 0.0D));
/*     */       }
/*     */       
/*  87 */     };
/*  88 */     this.descendTimer.runTaskTimer(FlyingCarpet.getInstance(), FlyingCarpet.getDescendSpeed(), FlyingCarpet.getDescendSpeed());
/*     */   }
/*     */   
/*     */   public boolean isCarpetBlock(Block b) {
/*  92 */     return isCarpetBlock(b.getLocation());
/*     */   }
/*     */   
/*     */   public boolean isCarpetBlock(Location loc) {
/*  96 */     for (BlockState state : this.blocks) {
/*  97 */       if (LocationUtils.locEqual(state.getLocation(), loc))
/*  98 */         return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 104 */     if (this.enabled == enabled) {
/* 105 */       return;
/*     */     }
/* 107 */     this.enabled = enabled;
/*     */     
/* 109 */     if (enabled) {
/* 110 */       createCarpet();
/*     */     } else
/* 112 */       removeCarpet();
/*     */   }
/*     */   
/*     */   public void setLocation(Location loc) {
/* 116 */     if ((!this.enabled) || (LocationUtils.locEqual(this.loc, loc))) {
/* 117 */       this.loc = loc;
/* 118 */       return;
/*     */     }
/*     */     
/* 121 */     this.loc = loc;
/*     */     
/* 123 */     createCarpet();
/*     */   }
/*     */   
/*     */   public void setTools(boolean tools) {
/* 127 */     if ((!this.enabled) || (this.tools == tools)) {
/* 128 */       this.tools = tools;
/* 129 */       return;
/*     */     }
/*     */     
/* 132 */     this.tools = tools;
/*     */     
/* 134 */     createCarpet();
/*     */   }
/*     */   
/*     */   public void setLight(boolean light) {
/* 138 */     if ((!this.enabled) || (this.light == light)) {
/* 139 */       this.light = light;
/* 140 */       return;
/*     */     }
/*     */     
/* 143 */     this.light = light;
/*     */     
/* 145 */     createCarpet();
/*     */   }
/*     */   
/*     */   public void removeCarpet()
/*     */   {
/* 150 */     for (BlockState state : this.blocks) {
/* 151 */       Block b = state.getBlock();
/*     */       
/* 153 */       b.setType(state.getType());
/* 154 */       b.setData(state.getRawData());
/*     */     }
/*     */     
/* 157 */     this.blocks = new ArrayList();
/*     */   }
/*     */   
/*     */   public void createCarpet()
/*     */   {
/* 162 */     if (!FlyingCarpet.getInstance().isCarpetAllowed(this.player.getLocation())) {
/* 163 */       setEnabled(false);
/* 164 */       Messages.get("message.region-remove").send(this.player);
/* 165 */       return;
/*     */     }
/*     */     
/* 168 */     List<Model> models = new ArrayList();
/*     */     
/* 170 */     models.add(FlyingCarpet.getBaseModel());
/*     */     
/* 172 */     if (this.tools) {
/* 173 */       models.add(FlyingCarpet.getToolsModel());
/*     */     }
/*     */     
/* 176 */     if (this.light) {
/* 177 */       models.add(FlyingCarpet.getLightModel());
/*     */     }
/*     */     
/* 180 */     Region[] regions = new Region[models.size()];
/*     */     
/* 182 */     for (int i = 0; i < regions.length; i++) {
/* 183 */       regions[i] = ((Model)models.get(i)).getRegion();
/*     */     }
/*     */     
/* 186 */     Region region = Region.combine(regions);
/*     */     
/* 188 */     List<CarpetBlock> newBlocks = new ArrayList();
/* 189 */     for (int x = region.getMin().getX(); x <= region.getMax().getX(); x++) {
/* 190 */       for (int y = region.getMin().getY(); y <= region.getMax().getY(); y++) {
/* 191 */         for (int z = region.getMin().getZ(); z <= region.getMax().getZ(); z++) {
/* 192 */           Location l = this.loc.clone().add(x, y, z);
/* 193 */           Vector3I offset = Model.getOffset(this.loc, l);
/*     */           
/* 195 */           BlockData data = BlockData.AIR;
/*     */           
/* 197 */           for (int i = 0; i < models.size(); i++) {
/* 198 */             Model m = (Model)models.get(i);
/*     */             
/* 200 */             BlockData d = m.getBlockData(offset);
/*     */             
/* 202 */             if (d.getType() != Material.AIR) {
/* 203 */               data = d;
/*     */             }
/*     */           }
/* 206 */           if (data.getType() != Material.AIR)
/*     */           {
/*     */ 
/* 209 */             newBlocks.add(new CarpetBlock(data, l));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 214 */     List<BlockState> states = new ArrayList();
/*     */     
/* 216 */     Iterator<BlockState> stateIterator = this.blocks.iterator();
/*     */     
/* 218 */     while (stateIterator.hasNext()) {
/* 219 */       BlockState state = (BlockState)stateIterator.next();
/*     */       
/* 221 */       boolean found = false;
/* 222 */       Iterator<CarpetBlock> carpetIterator = newBlocks.iterator();
/* 223 */       while (carpetIterator.hasNext()) {
/* 224 */         CarpetBlock block = (CarpetBlock)carpetIterator.next();
/*     */         
/* 226 */         if (LocationUtils.locEqual(state.getLocation(), block.loc))
/*     */         {
/*     */ 
/* 229 */           found = true;
/*     */           
/* 231 */           carpetIterator.remove();
/* 232 */           states.add(state);
/*     */           
/* 234 */           block.blockData.apply(state.getBlock());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 239 */       if (!found) {
/* 240 */         Block b = state.getBlock();
/*     */         
/* 242 */         b.setTypeIdAndData(state.getTypeId(), state.getRawData(), false);
/*     */       }
/*     */     }
/*     */     
/* 246 */     Iterator<CarpetBlock> carpetIterator = newBlocks.iterator();
/* 247 */     CarpetBlock block; while (carpetIterator.hasNext()) {
/* 248 */       block = (CarpetBlock)carpetIterator.next();
/*     */       
/* 250 */       Block b = block.loc.getBlock();
/*     */       
/* 252 */       if (!FlyingCarpet.canPassThrough(b.getType(), b.getData())) {
/* 253 */         carpetIterator.remove();
/*     */       }
/*     */     }
/*     */     
/* 257 */     for (CarpetBlock block : newBlocks) {
/* 258 */       Block b = block.loc.getBlock();
/*     */       
/* 260 */       states.add(b.getState());
/*     */       
/* 262 */       block.blockData.apply(b);
/*     */     }
/*     */     
/* 265 */     this.blocks = states;
/*     */   }
/*     */   
/*     */   private class CarpetBlock
/*     */   {
/*     */     public BlockData blockData;
/*     */     public Location loc;
/*     */     
/*     */     public CarpetBlock(BlockData blockData, Location loc) {
/* 274 */       this.blockData = blockData;
/* 275 */       this.loc = loc;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/marcelo-frau/Dropbox/mundominecraft_/sources/FlyingCarpet/FlyingCarpet.jar!/me/sothatsit/flyingcarpet/UPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */