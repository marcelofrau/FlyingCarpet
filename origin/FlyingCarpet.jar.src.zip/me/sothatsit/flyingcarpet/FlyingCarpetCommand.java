/*     */ package me.sothatsit.flyingcarpet;
/*     */ 
/*     */ import java.util.Set;
/*     */ import me.sothatsit.flyingcarpet.message.Message;
/*     */ import me.sothatsit.flyingcarpet.message.Messages;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class FlyingCarpetCommand
/*     */   implements CommandExecutor
/*     */ {
/*     */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*     */   {
/*  16 */     if ((args.length != 0) && (args[0].equalsIgnoreCase("worldguard"))) {
/*  17 */       if (!sender.hasPermission("flyingcarpet.worldguard")) {
/*  18 */         Messages.get("error.no-permissions.worldguard").send(sender);
/*  19 */         return true;
/*     */       }
/*     */       
/*  22 */       if (!FlyingCarpet.getInstance().isWorldGuardHooked()) {
/*  23 */         Messages.get("error.worldguard-not-hooked").send(sender);
/*  24 */         return true;
/*     */       }
/*     */       
/*  27 */       if (args.length == 1) {
/*  28 */         Messages.get("error.invalid-arguments").argument("%valid%", "/mc worldguard <add:remove:list>").send(sender);
/*  29 */         return true;
/*     */       }
/*     */       
/*  32 */       if (args[1].equalsIgnoreCase("add")) {
/*  33 */         if (args.length != 3) {
/*  34 */           Messages.get("error.invalid-arguments").argument("%valid%", "/mc worldguard add <region>").send(sender);
/*  35 */           return true;
/*     */         }
/*     */         
/*  38 */         FlyingCarpet.getInstance().getWorldGuardHook().addBlacklistedRegion(args[2]);
/*  39 */         Messages.get("message.wg.add").argument("%region%", args[2]).send(sender);
/*  40 */         return true;
/*     */       }
/*     */       
/*  43 */       if (args[1].equalsIgnoreCase("remove")) {
/*  44 */         if (args.length != 3) {
/*  45 */           Messages.get("error.invalid-arguments").argument("%valid%", "/mc worldguard remove <region>").send(sender);
/*  46 */           return true;
/*     */         }
/*     */         
/*  49 */         FlyingCarpet.getInstance().getWorldGuardHook().removeBlacklistedRegion(args[2]);
/*  50 */         Messages.get("message.wg.remove").argument("%region%", args[2]).send(sender);
/*  51 */         return true;
/*     */       }
/*     */       
/*  54 */       if (args[1].equalsIgnoreCase("list")) {
/*  55 */         if (args.length != 2) {
/*  56 */           Messages.get("error.invalid-arguments").argument("%valid%", "/mc worldguard list").send(sender);
/*  57 */           return true;
/*     */         }
/*     */         
/*  60 */         Set<String> regions = FlyingCarpet.getInstance().getWorldGuardHook().getBlacklistedRegions();
/*     */         
/*  62 */         if (regions.size() == 0) {
/*  63 */           Messages.get("message.wg.list-none").send(sender);
/*  64 */           return true;
/*     */         }
/*     */         
/*  67 */         Messages.get("message.wg.list-header").send(sender);
/*     */         
/*  69 */         for (String region : regions) {
/*  70 */           Messages.get("message.wg.list-line").argument("%region%", region).send(sender);
/*     */         }
/*     */         
/*  73 */         return true;
/*     */       }
/*     */       
/*  76 */       Messages.get("error.invalid-arguments").argument("%valid%", "/mc worldguard <add:remove:list>").send(sender);
/*  77 */       return true;
/*     */     }
/*     */     
/*  80 */     if (!(sender instanceof Player)) {
/*  81 */       Messages.get("error.must-be-player").send(sender);
/*  82 */       return true;
/*     */     }
/*     */     
/*  85 */     Player p = (Player)sender;
/*     */     
/*  87 */     if (!p.hasPermission("flyingcarpet.use")) {
/*  88 */       Messages.get("error.no-permissions.carpet").send(sender);
/*  89 */       return true;
/*     */     }
/*     */     
/*  92 */     UPlayer up = FlyingCarpet.getInstance().getUPlayer(p);
/*     */     
/*  94 */     if (args.length == 0) {
/*  95 */       if ((!up.isEnabled()) && (!FlyingCarpet.getInstance().isCarpetAllowed(p.getLocation()))) {
/*  96 */         Messages.get("error.region-blocked").send(sender);
/*  97 */         return true;
/*     */       }
/*     */       
/* 100 */       up.setEnabled(!up.isEnabled());
/*     */       
/* 102 */       if (up.isEnabled()) {
/* 103 */         Messages.get("message.carpet-on").send(sender);
/*     */       } else {
/* 105 */         Messages.get("message.carpet-off").send(sender);
/*     */       }
/*     */       
/* 108 */       return true;
/*     */     }
/*     */     
/* 111 */     if (args[0].equalsIgnoreCase("on")) {
/* 112 */       if (args.length != 1) {
/* 113 */         Messages.get("error.invalid-arguments").argument("%valid%", "/mc on").send(sender);
/* 114 */         return true;
/*     */       }
/*     */       
/* 117 */       if (!FlyingCarpet.getInstance().isCarpetAllowed(p.getLocation())) {
/* 118 */         Messages.get("error.region-blocked").send(sender);
/* 119 */         return true;
/*     */       }
/*     */       
/* 122 */       up.setEnabled(true);
/*     */       
/* 124 */       Messages.get("message.carpet-on").send(sender);
/* 125 */       return true;
/*     */     }
/*     */     
/* 128 */     if (args[0].equalsIgnoreCase("off")) {
/* 129 */       if (args.length != 1) {
/* 130 */         Messages.get("error.invalid-arguments").argument("%valid%", "/mc off").send(sender);
/* 131 */         return true;
/*     */       }
/*     */       
/* 134 */       up.setEnabled(false);
/*     */       
/* 136 */       Messages.get("message.carpet-off").send(sender);
/* 137 */       return true;
/*     */     }
/*     */     
/* 140 */     if (args[0].equalsIgnoreCase("reload")) {
/* 141 */       if (!p.hasPermission("flyingcarpet.reload")) {
/* 142 */         Messages.get("error.no-permissions.reload").send(sender);
/* 143 */         return false;
/*     */       }
/*     */       
/* 146 */       if (args.length != 1) {
/* 147 */         Messages.get("error.invalid-arguments").argument("%valid%", "/mc off").send(sender);
/* 148 */         return true;
/*     */       }
/*     */       
/* 151 */       FlyingCarpet.getInstance().reloadConfiguration();
/*     */       
/* 153 */       Messages.get("message.reload").send(sender);
/* 154 */       return true;
/*     */     }
/*     */     
/* 157 */     if (args[0].equalsIgnoreCase("tools")) {
/* 158 */       if (!p.hasPermission("flyingcarpet.tools")) {
/* 159 */         Messages.get("error.no-permissions.tools").send(sender);
/* 160 */         return false;
/*     */       }
/*     */       
/* 163 */       if ((args.length != 1) && (args.length != 2)) {
/* 164 */         Messages.get("error.invalid-arguments").argument("%valid%", "/mc tools [on:off]").send(sender);
/* 165 */         return true;
/*     */       }
/*     */       
/* 168 */       if (args.length == 1) {
/* 169 */         up.setTools(!up.isTools());
/*     */         
/* 171 */         if (up.isTools()) {
/* 172 */           Messages.get("message.tools-on").send(sender);
/*     */         } else {
/* 174 */           Messages.get("message.tools-off").send(sender);
/*     */         }
/* 176 */         return true;
/*     */       }
/*     */       
/* 179 */       if (args[1].equalsIgnoreCase("on")) {
/* 180 */         up.setTools(true);
/*     */         
/* 182 */         Messages.get("message.tools-on").send(sender);
/* 183 */         return true;
/*     */       }
/*     */       
/* 186 */       if (args[1].equalsIgnoreCase("off")) {
/* 187 */         up.setTools(false);
/*     */         
/* 189 */         Messages.get("message.tools-off").send(sender);
/* 190 */         return true;
/*     */       }
/*     */       
/* 193 */       Messages.get("error.invalid-arguments").argument("%valid%", "/mc tools [on:off]").send(sender);
/* 194 */       return true;
/*     */     }
/*     */     
/* 197 */     if (args[0].equalsIgnoreCase("light")) {
/* 198 */       if (!p.hasPermission("flyingcarpet.light")) {
/* 199 */         Messages.get("error.no-permissions.light").send(sender);
/* 200 */         return true;
/*     */       }
/*     */       
/* 203 */       if ((args.length != 1) && (args.length != 2)) {
/* 204 */         Messages.get("error.invalid-arguments").argument("%valid%", "/mc light [on:off]").send(sender);
/* 205 */         return true;
/*     */       }
/*     */       
/* 208 */       if (args.length == 1) {
/* 209 */         up.setLight(!up.isLight());
/*     */         
/* 211 */         if (up.isLight()) {
/* 212 */           Messages.get("message.light-on").send(sender);
/*     */         } else {
/* 214 */           Messages.get("message.light-off").send(sender);
/*     */         }
/* 216 */         return true;
/*     */       }
/*     */       
/* 219 */       if (args[1].equalsIgnoreCase("on")) {
/* 220 */         up.setLight(true);
/*     */         
/* 222 */         Messages.get("message.light-on").send(sender);
/* 223 */         return true;
/*     */       }
/*     */       
/* 226 */       if (args[1].equalsIgnoreCase("off")) {
/* 227 */         up.setLight(false);
/*     */         
/* 229 */         Messages.get("message.light-off").send(sender);
/* 230 */         return true;
/*     */       }
/*     */       
/* 233 */       Messages.get("error.invalid-arguments").argument("%valid%", "/mc light [on:off]").send(sender);
/* 234 */       return true;
/*     */     }
/*     */     
/* 237 */     Messages.get("error.invalid-arguments").argument("%valid%", "/mc [on:off:tools:light" + ((FlyingCarpet.getInstance().isWorldGuardHooked()) && (p.hasPermission("flyingcarpet.worldguard")) ? ":worldguard" : "") + "]").send(sender);
/* 238 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/marcelo-frau/Dropbox/mundominecraft_/sources/FlyingCarpet/FlyingCarpet.jar!/me/sothatsit/flyingcarpet/FlyingCarpetCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */